<?php

namespace Core;

use Core\Config;
use PDO;

abstract class Model
{
	/**
	 * MySQL database connect
	 * @return object
	 */
	protected static function connect_db()
	{
		static $db = null;

		if ($db === null) 
        {
            $dsn = "pgsql:host=".Config::DB_HOST.";port=5432;dbname=".Config::DB_NAME.";";
			try 
            {
				$db = new PDO($dsn, Config::DB_USER, Config::DB_PASS,[PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION]);
			} 
            catch (\PDOException $e) 
            {
				throw new \Exception($e->getMessage(), $e->getCode());
				exit;
			}
		}

		return $db;
	}
}
