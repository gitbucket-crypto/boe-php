<?php 

namespace App\Endpoint\Deploy;

class Hardware
{
    public function __construct()
	{
		$this->model = new \App\Endpoint\Deploy\Crud();
	}

    protected function before()
    {
        if(!isset($_REQUEST['artifact']) | $_REQUEST['artifact']=='')
        {
            echo json_encode(['code'=>303,'msg'=>'Artifact UID não presente']); die();
        }
        if(!isset($_REQUEST['macaddress']) | $_REQUEST['macaddress']=='')
        {
            echo json_encode(['code'=>303,'msg'=>'Mac Address não presente']); die();
        }
        if(!isset($_REQUEST['hwinfo']) | $_REQUEST['hwinfo']=='')
        {
            echo json_encode(['code'=>303,'msg'=>'Hardware info não presente']); die();
        }
    }

    protected function previous()
    {
        if(!isset($_REQUEST['artifact']) | $_REQUEST['artifact']=='')
        {
            echo json_encode(['code'=>303,'msg'=>'Artifact UID não presente']); die();
        }
        if(!isset($_REQUEST['cpu']) | $_REQUEST['cpu']=='')
        {
            echo json_encode(['code'=>303,'msg'=>'O uso da CPU não está presente']); die();
        }
        if(!isset($_REQUEST['hdd']) | $_REQUEST['hdd']=='')
        {
            echo json_encode(['code'=>303,'msg'=>'O uso do HD não está presente']); die();
        }
        if(!isset($_REQUEST['tipo']) | $_REQUEST['tipo']=='')
        {
            echo json_encode(['code'=>303,'msg'=>'O tipo de log não está presente']); die();
        }
        if(!isset($_REQUEST['memory']) | $_REQUEST['memory']=='')
        {
            echo json_encode(['code'=>303,'msg'=>'O uso da  memoria não está presente']); die();
        }
        if(!isset($_REQUEST['temperature']) | $_REQUEST['temperature']=='')
        {
            echo json_encode(['code'=>303,'msg'=>'O log da temperatura não está presente']); die();
        }
    }

    public function info()
    {
        $this->before();
        $ret = $this->model->insert("artifact_x_hardware", "(uid, artifact, macaddress, datahora, hwinfo)", "(? , ? , ? , ? , ? )",[rand(), $_REQUEST['artifact'], $_REQUEST['macaddress'],'NOW()' ,$_REQUEST['hwinfo'] ]);
        if($ret)
        {
            echo json_encode(["code"=> 202,"msg"=> 'Cadastrado com sucesso' ]); die();
        }
        else 
        {
            $this->except(); exit;
        }
    }

    public function report()
    {
        $this->previous();

        $ret = $this->model->insert("nucreport", "(uid, memoria, cpu, hdd, tipo, artifact, datahora, temperature)", 
                                   "(? , ? , ? , ? , ? , ? , ? , ?)",
                                   [rand(), $_REQUEST['memory'], $_REQUEST['cpu'] , $_REQUEST['hdd'] ,$_REQUEST['tipo'] , $_REQUEST['artifact'],'NOW()', $_REQUEST['temperature']]);
        if($ret)
        {
            echo json_encode(["code"=> 202,"msg"=> 'Cadastrado com sucesso' ]); die();
        }
        else 
        {
            $this->except(); exit;
        }                           

    }

    protected function except()
    {
    }

    protected $model;
}