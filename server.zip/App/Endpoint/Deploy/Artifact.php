<?php

namespace App\Endpoint\Deploy;

use \Crud;

class Artifact  
{
	public function __construct()
	{
		$this->model = new \App\Endpoint\Deploy\Crud();
	}
	
	protected function before()
	{
		$ret = $this->model->getOne(' * ', "deployment", "nucmac='".$_REQUEST['mac']."'");
		if($ret!='no data')
		{
			echo json_encode(['code'=>303,'msg'=>'Mac Address ja cadstrado']); die();
		}
	}	

	public function addNew()
	{
		$this->before();

		$this->mac = $_REQUEST['mac'];

		$ret = $this->model->get(' * ', "deployment", " deployed='0' AND nucmac IS NULL", 'random()', '1');

		if(gettype($ret)=='array')
		{
			$this->artifact = $ret[0]["artifact"];
			$this->after();
		}
	}

	protected function after()
	{
		$ret = $this->model->update("deployment",'deployed=? , datehorahandshake=? , nucmac=?', "artifact=?", ['1', 'NOW()', $this->mac, $this->artifact ]);
		if($ret)
		{
			echo json_encode(["code"=> 202,"msg"=>  $this->artifact ]); die();
		}
		else
		{
			$this->except();
		}
	}

	protected function except()
	{

	}

	protected $model;
	protected $mac;
	protected $artifact;
	
}

?>