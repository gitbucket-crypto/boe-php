<?php 

namespace App\Endpoint\Deploy;

class Logger
{
    public function __construct()
	{
		$this->model = new \App\Endpoint\Deploy\Crud();
	}

    protected function before()
    {
        if(!isset($_REQUEST['artifact']) | $_REQUEST['artifact']=='')
        {
            echo json_encode(['code'=>303,'msg'=>'Artifact UID não presente']); die();
        }
        if(!isset($_REQUEST['log']) | $_REQUEST['log']=='')
        {
            echo json_encode(['code'=>303,'msg'=>'Log não presente']); die();
        }
    }

    public function addNew()
    {
        $this->before();

        $ret = $this->model->insert("deploylogs", "(uid, datahora, artifact, texto)", "( ? , ? , ? , ? )",[uniqid(),'NOW()', $_REQUEST['artifact'], $_REQUEST['log'] ]);
        if($ret)
        {
            echo json_encode(["code"=> 202,"msg"=> 'Log cadastrado com sucesso' ]); die();
        }
        else 
        {
            $this->except(); exit;
        }
    }

    public function except()
    {

    }
}

?>