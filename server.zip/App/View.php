<?php

namespace App;


class View
{
    public static function render(string $view, array $args = []): void
	{
		extract($args, EXTR_SKIP);

		if(!isset($_SERVER['assets']))
		{
			$_SERVER['assets'] = \Core\Config::ASSETS;
		}

		$view.='.runner.php';

		$file = dirname(__DIR__) . "/App/Views/$view";

		if (is_readable($file) && file_exists($file))
			require_once $file;
		else
			throw new \Exception("$file não encontrado!");
	}
}

?>