import subprocess, sys

#php-cgi -f index.php left=1058 right=1067 class=A language=English
#subprocess.run("killall -s 9 python3.11", shell = True, executable="/bin/bash")
#subprocess.check_output(["php -f test.php left=1058 right=1067 class=A language=English"], shell=True, executable="/bin/bash" , capture_output=True)
subprocess.run("php  test.php left=1058 right=1067 class=A language=English", shell = True, executable="/bin/bash")