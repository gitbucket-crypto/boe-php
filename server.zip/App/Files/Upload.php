<?php

namespace App\Files;

use \App\Endpoint\Deploy\Crud;

class Upload
{
    public function __construct()
	{
		$this->model = new \App\Endpoint\Deploy\Crud();
	}

    protected function before()
    {
        if(count($_FILES)==0 | empty($_FILES))
        {
            echo json_encode(['code'=>303,'msg'=>'Nenhum arquivo enviado.']); exit;
        }
    }

    public function upload()
    {
        $this->before();
        $target_dir =\Core\Config::PATH;
        if(intval(count($_FILES))<3)
        {
            echo json_encode(['code'=>303,'msg'=>'Por favor envie os tres arquivos soc.py, report.py e modem.py.']); exit;
        }
        if(basename($_FILES["deployFiles1"]["name"])!='soc.py')
        {
            echo json_encode(['code'=>303,'msg'=>'Arquivo diferente de soc.py']); exit;
        }
        if(basename($_FILES["deployFiles2"]["name"])!='report.py')
        {
            echo json_encode(['code'=>303,'msg'=>'Arquivo diferente de report.py']); exit;
        }
        if(basename($_FILES["deployFiles3"]["name"])!='modem.py')
        {
            echo json_encode(['code'=>303,'msg'=>'Arquivo diferente de modem.py']); exit;
        }

        $target_file1 = $target_dir . basename($_FILES["deployFiles1"]["name"]);
        $target_file2 = $target_dir . basename($_FILES["deployFiles2"]["name"]);
        $target_file3 = $target_dir . basename($_FILES["deployFiles3"]["name"]);

        $imageFileType1 = strtolower(pathinfo($target_file1,PATHINFO_EXTENSION));
        $imageFileType2 = strtolower(pathinfo($target_file2,PATHINFO_EXTENSION));
        $imageFileType3 = strtolower(pathinfo($target_file3,PATHINFO_EXTENSION));

        $fileExet= ['.py,.PY','py'];

        if( in_array($imageFileType1,$fileExet)!=true |
        in_array($imageFileType2,$fileExet)!=true | 
        in_array($imageFileType3,$fileExet)!=true ) 
        {   
            echo json_encode(['code'=>303,'msg'=>'Por favor verifique se você está fazendo o upload do arquivos python']); exit;
        }

        
        try
        {
            if(file_exists('soc.py'))
            {
                unlink('soc.py');
            }
            if(file_exists('report.py'))
            {
               unlink('report.py');
            }
            if(file_exists('modem.py'))
            {
                unlink('modem.py');
            } 
            if(move_uploaded_file($_FILES["deployFiles1"]["tmp_name"], $target_file1)==true && 
               move_uploaded_file($_FILES["deployFiles2"]["tmp_name"], $target_file2)==true &&
               move_uploaded_file($_FILES["deployFiles3"]["tmp_name"], $target_file3)==true)
            {
                $ret = $this->model->update('updatefiles', 'update=? , datahoraupdate=?', 'update=? OR update=?' , ['1', 'NOW()', '0' , '1' ]);
                if($ret)
                {
                    echo json_encode(["code"=> 202,"msg"=> 'Arquivos atualizados com sucesso' ]); die();
                }
                else
                {
                    $this->except();
                }
            }   
        }
        catch(Exception $e)
        {
            echo json_encode(['code'=>503,'msg'=>$e->getMessage() ]); exit;
        }

    }

    public function deploy()
    {
        $this->before();
        $target_dir =\Core\Config::PATH.'php/';

        if(intval(count($_FILES))<2)
        {
            echo json_encode(['code'=>303,'msg'=>'Por favor envie os tres arquivos soc.py, report.py e modem.py.']); exit;
        }

        if(basename($_FILES["deployFiles1"]["name"])!='robot.php')
        {
            echo json_encode(['code'=>303,'msg'=>'Arquivo diferente de robot.php']); exit;
        }
        if(basename($_FILES["deployFiles2"]["name"])!='prepare.php')
        {
            echo json_encode(['code'=>303,'msg'=>'Arquivo diferente de prepare.php']); exit;
        }

        $target_file1 = $target_dir . basename($_FILES["deployFiles1"]["name"]);
        $target_file2 = $target_dir . basename($_FILES["deployFiles2"]["name"]);

        $imageFileType1 = strtolower(pathinfo($target_file1,PATHINFO_EXTENSION));
        $imageFileType2 = strtolower(pathinfo($target_file2,PATHINFO_EXTENSION));

        $versionRobot  = file_get_contents(\Core\Config::PATH.'version\robot.txt');
        $versionPrepare  = file_get_contents(\Core\Config::PATH.'version\prepare.txt');

        $versionRobot = ltrim(trim($versionRobot),' ');
        $versionRobot = substr( $versionRobot, 1, strlen( $versionRobot));

        $versionPrepare = ltrim(trim($versionPrepare),' ');
        $versionPrepare = substr( $versionPrepare, 1, strlen( $versionPrepare));

        $versionRobot  = intval($versionRobot) + intval(1);
        $versionPrepare  = intval($versionPrepare) + intval(1);

        $versionRobot = 'v'.number_format((float)$versionRobot, 1, '.', '');
        $versionPrepare = 'v'.number_format((float)$versionPrepare, 1, '.', '');

        unlink(\Core\Config::PATH.'version\robot.txt');
        unlink(\Core\Config::PATH.'version\prepare.txt');

        $f1 = fopen(\Core\Config::PATH.'version\robot.txt',"w+");
        $f2 = fopen(\Core\Config::PATH.'version\prepare.txt',"w+");

        fwrite($f1, $versionRobot);
        fwrite($f2, $versionPrepare);

        fclose($f1);
        fclose($f2);

        $fileExet= ['.php,.PHP','php'];

        if( in_array($imageFileType1,$fileExet)!=true |
            in_array($imageFileType2,$fileExet)!=true ) 
        {   
            echo json_encode(['code'=>303,'msg'=>'Por favor verifique se você está fazendo o upload do arquivos PHP']); exit;
        }
        try
        {
            if(file_exists(\Core\Config::PATH.'php\robotphp'))
            {
                unlink(\Core\Config::PATH.'php/robotphp');
            }
            if(file_exists(\Core\Config::PATH.'php\preparephp'))
            {
               unlink(\Core\Config::PATH.'php\preparephp');
            }
            
            if(move_uploaded_file($_FILES["deployFiles1"]["tmp_name"], $target_file1)==true && 
               move_uploaded_file($_FILES["deployFiles2"]["tmp_name"], $target_file2)==true 
              )
            {
                if(file_exists(\Core\Config::PATH.'php\robot.php'))
                {
                    rename(\Core\Config::PATH.'php\robot.php', \Core\Config::PATH.'php\robotphp');
                }
                if(file_exists(\Core\Config::PATH.'php\prepare.php'))
                {
                    rename(\Core\Config::PATH.'php\prepare.php', \Core\Config::PATH.'php\preparephp');
                }

                $ret = $this->model->update('updatephp', 'update=? , datahoraupdate=?', 'update=? OR update=?' , ['1', 'NOW()', '0' , '1' ]);
                if($ret)
                {
                    echo json_encode(["code"=> 202,"msg"=> 'Arquivos atualizados com sucesso' ]); die();
                }
                else
                {
                    $this->except();
                }
            }   
        }
        catch(Exception $e)
        {
            echo json_encode(['code'=>503,'msg'=>$e->getMessage() ]); exit;
        }

    }

    protected function except()
	{

	}

    protected $model;

}


?>