<?php
date_default_timezone_set('America/Sao_Paulo');

require_once('vendor/autoload.php');


new \Core\Config(\Core\Config::INI);

$router = new  \Core\Router();
$handler = new \Core\Handler();

$router->before('GET', '/.*', function() 
{
    global $handler;
    if(!isset($_GET['csrf']))
    {
        $handler->handle($handler::CALLABLE,  "App\View@render" ,'401/index' ); die();
    }
});

$router->before('POST', '/.*', function() 
{
    global $handler;
    if(!isset($_POST['csrf']))
    {
        $handler->handle($handler::CALLABLE,  "App\View@render" ,'401/index' );die();
    }
});

$router->post('/rmc/nuc/add', function(){
    //http://localhost/boe-php/rmc/nuc/add
    global $handler;   
    $handler->handle($handler::CALLABLE,  "App\Endpoint\Deploy\Artifact@addNew" ,$_REQUEST ); 
});

$router->post('/rmc/nuc/log', function(){
    //http://localhost/boe-php/rmc/nuc/log
    global $handler;   
    $handler->handle($handler::CALLABLE,  "App\Endpoint\Deploy\Logger@addNew" ,$_REQUEST ); 
});

$router->post('/rmc/nuc/hwinfo/add', function(){
    //http://localhost/boe-php/rmc/nuc/hwinfo/add
    global $handler;   
    $handler->handle($handler::CALLABLE,  "App\Endpoint\Deploy\Hardware@info" ,$_REQUEST ); 
});

$router->post('/rmc/nuc/report/add', function(){
    global $handler;   
    $handler->handle($handler::CALLABLE,  "App\Endpoint\Deploy\Hardware@report" ,$_REQUEST ); 
});

$router->post('/rmc/nuc/command/status', function(){
    global $handler;   
    $handler->handle($handler::CALLABLE,  "App\Endpoint\Deploy\Commander@commandStatus" ,$_REQUEST ); 
});

$router->post('/rmc/nuc/command/get', function(){
    global $handler;   
    $handler->handle($handler::CALLABLE,  "App\Endpoint\Deploy\Commander@command" ,$_REQUEST ); 
});
//##########################UPDADE PY FILES#############################

$router->get('/rmc/nuc/files/update',function(){
    global $handler;   
    $handler->handle($handler::CALLABLE,  "App\View@render" ,'update/index' ); 
});

$router->post('/rmc/nuc/files/upload',function(){
    global $handler;   
    $handler->handle($handler::CALLABLE,  "App\Files\Upload@upload"  , $_FILES); 
});
//######################################################################

$router->get('/rmc/nuc/files/get', function()
{
    if(file_exists(\Core\Config::PATH.$_GET['file']))
    {
        header('Location: '.\Core\Config::FILES.$_GET['file']); exit;
    }
});

//##########################GET PHP VERSION###############################
$router->get('/rmc/nuc/deploy/version', function()
{
    if(file_exists(\Core\Config::PATH.'version/robot.txt'))
    {
         echo file_get_contents(\Core\Config::FILES.'version/robot.txt'); exit;
    }
    else echo 'v0'; exit;
});

$router->get('/rmc/nuc/prepare/version', function()
{
    if(file_exists(\Core\Config::PATH.'version/prepare.txt'))
    {
         echo file_get_contents(\Core\Config::FILES.'version/prepare.txt'); exit;
    }
    else echo 'v0';exit;
});

//##########################GET PHP FILES##################################
$router->get('/rmc/nuc/deploy/get', function()
{
    if(file_exists(\Core\Config::PATH.'robotphp'))
    {
        header('Location: '.\Core\Config::FILES.'robotphp'); exit;
    }
    else echo 'v0'; exit;
});

$router->get('/rmc/nuc/prepare/get', function()
{
    if(file_exists(\Core\Config::PATH.'preparephp'))
    {
        header('Location: '.\Core\Config::FILES.'preparephp'); exit;
    }
    else echo 'v0';exit;
});
//##########################################################################

//############################UPDATE PHP FILES##############################
$router->get('/rmc/nuc/deploy/update', function()
{
    global $handler;   
    $handler->handle($handler::CALLABLE,  "App\View@render" ,'deploy/index' ); 
});

$router->post('/rmc/nuc/deploy/upload', function()
{
    global $handler;   
    $handler->handle($handler::CALLABLE,  "App\Files\Upload@deploy"  , $_FILES); 
});
//##########################################################################

$router->set404(function() 
{
    global $handler;
    $handler->handle($handler::CALLABLE,  "App\View@render" ,'404/index' );die();
});

try
{
    $router->run();
}
catch(Exception $e)
{
    echo $e->getMessage(); die();
}
?>