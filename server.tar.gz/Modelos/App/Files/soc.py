import socket
import subprocess, sys
import time
import requests
import uuid
#from api_nuc import msg
import json
import hashlib
##############################################################################################################
#python3 -m venv env
#source env/bin/activate

TCP_IP = '192.168.1.59'
TCP_PORT = 55502
BUFFER_SIZE = 1146  # Normally 1024, but we want fast response
NUMBER_OF_CONECTIONS = 1
EOL = '\n'

##############################################################################################################
#subprocess.run("killall -s 9 python3.11", shell = True, executable="/bin/bash")
soc = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
soc.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
soc.bind((TCP_IP, TCP_PORT)) 
soc.listen(NUMBER_OF_CONECTIONS)
finalData = '';
conn, addr = soc.accept()
#print ('--- ENDEREÇO DE CONEXAO:'+ str(addr))
go = True
while(go):
    data = conn.recv(1146)
    if not data:
        print('NO DATA !!!')
        go = False
        break
    data =str(bytes.hex(data))   
    if  len(data) >= BUFFER_SIZE:
        #print(finalData)
        #subprocess.run("php  parser.php "+str(finalData)+"", shell = True, executable="/bin/bash") 
        mac_address = uuid.getnode()
        mac_address_hex = ':'.join(['{:02x}'.format((mac_address >> elements) & 0xff) for elements in range(0,8*6,8)][::-1])
        localIP = [(s.connect(('8.8.8.8', 53)), s.getsockname()[0], s.close()) for s in [socket.socket(socket.AF_INET, socket.SOCK_DGRAM)]][0][1]
        publicIP = ''#requests.get('http://ipinfo.io/json').json()['ip']
        params = {'data': str(data) , 'mac':mac_address_hex , 'localIP':localIP, 'publicIP':publicIP, 'csfr':'237483788'}
        r = requests.post("http://localhost/boe/server.php", data=params)
        print(r.text)
        time.sleep(10)      
        finalData =''    
