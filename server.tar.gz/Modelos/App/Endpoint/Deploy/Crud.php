<?php 

namespace App\Endpoint\Deploy;


class Crud extends \Core\Model
{
    public function __construct()
    {
        $this->connect();
    }

    public function connect()
    {
        $this->conn =\Core\Model::connect_db();
    }

    public function get($params, $table,$where ,$order, $limit )
    {
        $SQL = 'SELECT '.$params.' FROM '.$table.' WHERE '.$where.' ORDER BY '.$order. ' LIMIT '.$limit;
        $stmt = $this->conn->query($SQL);
        $result =  $stmt ->fetchAll(\PDO::FETCH_ASSOC);       
        return sizeof($result) ? $result : 'no slot';
    }

    public function getAll($params, $table, $order, $limit )
    {
        $SQL = 'SELECT '.$params.' FROM '.$table.' ORDER BY '.$order. 'LIMIT '.$limit;
        $stmt = $this->conn->query($SQL);
        $result =  $stmt ->fetchAll(\PDO::FETCH_ASSOC);       
        return sizeof($result) ? $result : 'no slot';
    }

    public function getOne($params, $table, $where)
    {   
        $SQL = 'SELECT '.$params.' FROM '.$table.' WHERE '.$where;
        $stmt = $this->conn->query($SQL);
        $result =  $stmt ->fetchAll(\PDO::FETCH_ASSOC);       
        return sizeof($result) ? $result : 'no data';
    }

    public function update($table, $fileds, $where, array $params)
    {
        $SQL='UPDATE '.$table.' SET '.$fileds.' WHERE '.$where;
        $stmt = $this->conn->prepare($SQL);
        if($stmt->execute($params)==true)
        {
            return true;
        }
        else return false;
    }

    public function insert($table, $fields, $values, array $params)
    {
        $SQL ='INSERT INTO '.$table.' '.$fields.' VALUES '.$values;
        $stmt = $this->conn->prepare($SQL);
        if($stmt->execute($params)==true)
        {
            return true;
        }
        else return false;
    }

    public function asterisk($SQL)
    {
        $stmt = $this->conn->query($SQL);
        $result =  $stmt ->fetchAll(\PDO::FETCH_ASSOC);  
        return empty($result) ? $result : 'no data';
    }

    private $conn;

}


?>