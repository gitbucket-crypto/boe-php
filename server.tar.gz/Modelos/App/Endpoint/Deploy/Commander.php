<?php

namespace App\Endpoint\Deploy;


class Commander
{
    public function __construct()
	{
		$this->model = new \App\Endpoint\Deploy\Crud();
	}

    protected function before()
    {
        if(!isset($_POST['artifact']) | $_POST['artifact']=='')
        {
            echo json_encode(['code'=>303,'msg'=>'Artifact UID não presente']); die();
        }
    }

    protected function previous()
    {
        if(!isset($_POST['command']) | $_POST['command']=='')
        {
            echo json_encode(['code'=>303,'msg'=>'O comando não presente']); die();
        }
        if(!isset($_POST['status']) | $_POST['status']=='')
        {
            echo json_encode(['code'=>303,'msg'=>'O status comando não presente']); die();
        }
    }

    public function commandStatus()
    {
        $this->before();
        $this->previous();
        $ret = $this->model->update('artifact_x_command', " status=? ", " artifact=? AND command=?", [$_POST['status'] , $_POST['artifact'], $_POST['command']] );
        if($ret)
        {
            echo json_encode(["code"=> 202,"msg"=> 'Status cadastrado com sucesso' ]); die();
        }
        else 
        {
            $this->except(); exit;
        }

    }

    public function command()
    {
        $this->before();

        $SQL="SELECT a.command FROM artifact_x_command a 
        JOIN artifact_x_command b ON a.artifact = b.artifact 
        AND a.artifact ='".$_POST['artifact']."'
        WHERE  a.datahorahandshake =''
        OR b.datahorahandshake IS NULL LIMIT 1";

        $ret =  $this->model->asterisk($SQL);
        if($ret=='no data')
        {
            echo json_encode(['code'=>200, 'msg'=>'false']);  die();  
        }
        $up = $this->model->update('artifact_x_command', "datahorahandshake=?", "artifact=?", [$_POST['artifact'], date("Y-m-d H:i:s")]);
        if($up)
        {
            echo json_encode(["code"=> 202,"msg"=> $ret[0]['command']]); die();
        }
        else 
        {
            $this->except(); exit;
        }

    }

    protected function except()
    {
    }



    protected $model;

}

?>