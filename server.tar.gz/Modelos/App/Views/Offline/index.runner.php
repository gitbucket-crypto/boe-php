<!DOCTYPE html>
<html lang="en" >
<head>
  <meta charset="UTF-8">
  <title>Em Manutenção</title>
  <link rel="stylesheet" href="./style.css">

</head>
<body>
<!-- partial:index.partial.html -->
<html>
    <head>
        <meta charset="utf-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <title></title>
        <meta name="description" content="">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <link rel="stylesheet" href="<?php echo $_SERVER['assets'];?>offline.css">
    </head>
    <body>
        <div class="container">
            <div class="content">
                <p>Sistema está em manutenção</p>
                <h1><span>Terminaremos </span> Logo</h1>
                <div class="launch-time">
                    <div>
                        <p id="days">00</p>
                        <span>Dias</span>
                    </div>
                    <div>
                        <p id="hours">04</p>
                        <span>Horas</span>
                    </div>
                    <div>
                        <p id="minutes">20</p>
                        <span>Minutos</span>
                    </div>
                    <div>
                        <p id="seconds">50</p>
                        <span>Secondos</span>
                    </div>
                </div>
            </div>
            <img src="https://i.postimg.cc/PfwZ6bDk/rocket.png" class="rocket">
        </div>
    </body>
</html>
<!-- partial -->
  <script  src="<?php echo $_SERVER['assets'];?>offline.js"></script>

</body>
</html>
