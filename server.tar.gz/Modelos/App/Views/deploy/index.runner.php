<?php 
ini_set('upload_max_filesize', '30M');

?>

<!DOCTYPE html>
<html lang="pt">
<head>
  <title>Atualizador de Aquivo</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
  <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
  <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
</head>
<body>

<div class="container-fluid p-5 bg-primary text-white text-center" >
  <h2>Atualizar arquivos robot e prepare</h2>
       <p style="font-size:18px" id='text1'></p>
</div>
  
<div class="container mt-5">
  <div class="row">
    <div class="col-sm-2">      
    </div>
    <div class="col-sm-8">
        <form action="" enctype="multipart/form-data" id='formUpdate'>
            <div class="mb-3 mt-3">
                <label for="deployFiles1" class="form-label">robot.php</label>
                <input type="file" class="form-control" id="deployFiles1" name="deployFiles1"  accept=".php">
            </div>
            <div class="mb-3">
                <label for="deployFiles2" class="form-label">prepare.php</label>
                <input type="file" class="form-control" id="deployFiles2" name="deployFiles2" accept=".php">
            </div>
            
            <div class="form-check mb-3">
            </div>
            <button type="buttom" class="btn btn-primary" onclick='uploadFile()' >Atualizar</button>
    	</form>
    </div>
   
  </div>
  <div class="col-sm-2"> 
        <br>   
        <p></p> 
    </div>
</div>
<script>
    
    if ( window.history.replaceState ) 
    {
        window.history.replaceState( null, null, window.location.href );
    }

    function uploadFile()
    {
        event.preventDefault();
       
        let data = new FormData();
            data.append('csrf', "<?php echo md5(time()); ?>");
            data.append('deployFiles1', document.getElementById('deployFiles1').files[0]);
            data.append('deployFiles2', document.getElementById('deployFiles2').files[0]);
            upload(data);
    }

    async function upload(data)
    {
        let url = "<?php echo \Core\Config::URL; ?>"+'/rmc/nuc/deploy/upload';
        const response = await fetch(url, {
		        method: 'POST',
		        credentials: 'same-origin',
		        body: data
		});

        const resp = await response.text();
        if(resp)
        {
            let rsp = JSON.parse(resp);
            console.log(rsp);
            document.getElementById('text1').innerHTML = rsp.msg; 
            if(rsp.code=='202' | rsp.code==202)
            {
                document.getElementById("formUpdate").reset(); 
            }
            setTimeout(() => 
            {
                    document.getElementById('text1').innerHTML ='';
            }, 50000);
        }
    }
</script>
</body>
</html>  

